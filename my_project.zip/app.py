from flask import Flask, render_template, request, redirect, url_for, session
from data import users

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Kunci untuk sesi login

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def handle_login():
    username = request.form['username']
    user_id = request.form['user_id']

    if username in users and users[username] == user_id:
        session['user'] = username
        return redirect(url_for('dashboard'))
    else:
        return "Login failed, please check your username or ID!", 401

@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        return render_template('dashboard.html', username=session['user'])
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
