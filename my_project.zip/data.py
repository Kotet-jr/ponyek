users = {
    'muklis': '12345',  # Contoh data
    'bubu': '67890'
}
